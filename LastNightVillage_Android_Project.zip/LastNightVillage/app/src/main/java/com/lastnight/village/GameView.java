package com.lastnight.village;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class GameView extends View {
    private final Paint p = new Paint(3);
    private final Random rng = new Random();
    private final ArrayList<Enemy> enemies = new ArrayList<>();
    private final ArrayList<Bullet> bullets = new ArrayList<>();
    private final ArrayList<RectF> houses = new ArrayList<>();
    private long last=0, spawn=0, hurt=0;
    private float px=0, py=0, joyX=0, joyY=0, aimX=0, aimY=0;
    private float moveX=0, moveY=0;
    private int hp=100, ammo=12, reserve=48, kills=0, medkits=2;
    private boolean firing=false, gameOver=false, won=false, started=false;
    private int wave=1;
    private final float worldW=1800, worldH=1200;
    private float camX=0, camY=0;
    private final String[] names={"WALKER","RUNNER","THE BUTCHER"};

    static class Enemy { float x,y,hp,speed; int type; Enemy(float a,float b,int t){x=a;y=b;type=t;hp=t==2?5: (t==1?2:1);speed=t==1?82:(t==2?43:52);} }
    static class Bullet { float x,y,vx,vy; Bullet(float a,float b,float c,float d){x=a;y=b;vx=c;vy=d;} }

    public GameView(Context c) {
        super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        px=worldW/2; py=worldH/2;
        // village buildings and fences
        houses.add(new RectF(220,180,500,380)); houses.add(new RectF(850,120,1120,340));
        houses.add(new RectF(1300,460,1600,680)); houses.add(new RectF(300,800,600,1050));
        houses.add(new RectF(900,850,1160,1080));
        for(int i=0;i<8;i++) spawnEnemy();
    }

    private void spawnEnemy(){
        double a=rng.nextDouble()*Math.PI*2; float d=430+rng.nextInt(180);
        int t=(kills>7 && rng.nextInt(5)==0)?2:(rng.nextInt(4)==0?1:0);
        enemies.add(new Enemy(clamp(px+(float)Math.cos(a)*d,30,worldW-30),clamp(py+(float)Math.sin(a)*d,30,worldH-30),t));
    }
    private float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
    private float dist(float a,float b,float c,float d){return (float)Math.hypot(a-c,b-d);}
    private void text(Canvas c,String s,float x,float y,float size,int color){
        p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));c.drawText(s,x,y,p);
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c); float dt=last==0?0:Math.min(.04f,(System.currentTimeMillis()-last)/1000f);last=System.currentTimeMillis();
        int w=getWidth(),h=getHeight(); if(!started){drawStart(c,w,h);postInvalidateDelayed(16);return;}
        if(!gameOver&&!won) update(dt);
        camX=clamp(px-w*.5f,0,worldW-w);camY=clamp(py-h*.5f,0,worldH-h);
        c.save();c.translate(-camX,-camY);
        p.setColor(Color.rgb(32,42,34));c.drawRect(0,0,worldW,worldH,p);
        // muddy paths
        p.setColor(Color.rgb(65,61,49));c.drawRect(0,520,worldW,680,p);c.drawRect(760,0,920,worldH,p);
        p.setColor(Color.rgb(46,52,40)); for(int i=0;i<90;i++){float x=(i*197)%1750,y=(i*131)%1150;c.drawCircle(x,y,8+(i%4)*3,p);}
        for(RectF r:houses){p.setColor(Color.rgb(82,67,54));c.drawRoundRect(r,8,8,p);p.setColor(Color.rgb(42,31,28));c.drawRect(r.left+25,r.top+35,r.right-25,r.bottom-20,p);p.setColor(Color.rgb(112,45,37));Path roof=new Path();roof.moveTo(r.left-15,r.top+10);roof.lineTo((r.left+r.right)/2,r.top-65);roof.lineTo(r.right+15,r.top+10);roof.close();c.drawPath(roof,p);}
        // player
        p.setColor(Color.BLACK);c.drawCircle(px,py+12,18,p);p.setColor(Color.rgb(65,130,150));c.drawCircle(px,py,15,p);
        p.setColor(Color.rgb(220,190,150));c.drawCircle(px,py-18,9,p);
        p.setColor(Color.DKGRAY);c.drawLine(px,py,px+aimX*28,py+aimY*28,p);
        // bullets
        p.setColor(Color.YELLOW);for(Bullet b:bullets)c.drawCircle(b.x,b.y,5,p);
        // enemies
        for(Enemy e:enemies){p.setColor(e.type==2?Color.rgb(90,15,12):Color.rgb(105,115,75));c.drawCircle(e.x,e.y, e.type==2?25:17,p);p.setColor(Color.rgb(190,35,25));c.drawCircle(e.x-6,e.y-4,3,p);c.drawCircle(e.x+6,e.y-4,3,p);}
        c.restore();
        // flashlight vignette
        p.setColor(0x99000000);c.drawRect(0,0,w,h,p);p.setShader(new RadialGradient(w/2,h/2,Math.min(w,h)*.52f,new int[]{0x00FFFFFF,0x33000000,0xDD000000},null,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
        drawHud(c,w,h);
        if(gameOver||won){p.setColor(0xCC000000);c.drawRect(0,0,w,h,p);text(c,won?"VILLAGE CLEARED":"YOU DIED",w*.36f,h*.43f,54,Color.WHITE);text(c,"TAP TO RESTART",w*.39f,h*.55f,24,Color.rgb(220,70,55));}
        postInvalidateDelayed(16);
    }
    private void update(float dt){
        float speed=190; float nx=px+moveX*speed*dt,ny=py+moveY*speed*dt;
        boolean blocked=false;for(RectF r:houses)if(r.contains(nx,ny))blocked=true;
        if(!blocked){px=clamp(nx,20,worldW-20);py=clamp(ny,20,worldH-20);}
        if(firing && System.currentTimeMillis()-spawn>260){shoot();spawn=System.currentTimeMillis();}
        Iterator<Bullet> bi=bullets.iterator();while(bi.hasNext()){Bullet b=bi.next();b.x+=b.vx*dt;b.y+=b.vy*dt;if(b.x<0||b.y<0||b.x>worldW||b.y>worldH){bi.remove();continue;}
            Iterator<Enemy> ei=enemies.iterator();boolean hit=false;while(ei.hasNext()){Enemy e=ei.next();if(dist(b.x,b.y,e.x,e.y)<23){e.hp--;hit=true;if(e.hp<=0){ei.remove();kills++;if(kills>=20)won=true;}break;}}if(hit)bi.remove();}
        for(Enemy e:enemies){float dx=px-e.x,dy=py-e.y,d=Math.max(1,(float)Math.hypot(dx,dy));e.x+=dx/d*e.speed*dt;e.y+=dy/d*e.speed*dt;if(d<30&&System.currentTimeMillis()-hurt>650){hp-=e.type==2?14:7;hurt=System.currentTimeMillis();if(hp<=0)gameOver=true;}}
        if(enemies.size()<7&&System.currentTimeMillis()-spawn>1600)spawnEnemy();
    }
    private void shoot(){if(ammo<=0)return;ammo--;float ax=aimX,ay=aimY;if(Math.abs(ax)+Math.abs(ay)<.1f){ax=1;ay=0;}bullets.add(new Bullet(px+ax*20,py+ay*20,ax*620,ay*620));}
    private void drawHud(Canvas c,int w,int h){
        p.setColor(0xBB080B0C);c.drawRoundRect(18,15,260,90,12,12,p);text(c,"HP "+hp+"     AMMO "+ammo+"/"+reserve,32,48,22,Color.WHITE);text(c,"KILLS "+kills+"/20     MED "+medkits,32,76,17,Color.rgb(220,210,180));
        // joystick
        p.setColor(0x66888888);c.drawCircle(100,h-105,65,p);p.setColor(0xAAE0E0E0);c.drawCircle(100+moveX*35,h-105+moveY*35,27,p);
        p.setColor(0x88A52B25);c.drawCircle(w-105,h-105,65,p);text(c,"FIRE",w-137,h-97,22,Color.WHITE);
        p.setColor(0xAA333333);c.drawCircle(w-245,h-70,34,p);text(c,"R",w-254,h-61,25,Color.WHITE);
        p.setColor(0xAA285C3D);c.drawCircle(w-105,h-235,32,p);text(c,"+",w-114,h-224,28,Color.WHITE);
    }
    private void drawStart(Canvas c,int w,int h){
        p.setColor(Color.rgb(8,12,12));c.drawColor(Color.rgb(8,12,12));
        text(c,"THE LAST NIGHT",w*.28f,h*.27f,52,Color.rgb(190,45,35));
        text(c,"VILLAGE",w*.42f,h*.37f,32,Color.LTGRAY);
        text(c,"SURVIVE THE NIGHT",w*.34f,h*.55f,25,Color.WHITE);
        text(c,"TAP TO START",w*.40f,h*.72f,22,Color.rgb(210,180,130));
        text(c,"MOVE  •  AIM  •  SHOOT  •  SURVIVE",w*.29f,h*.84f,18,Color.GRAY);
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        float x=e.getX(),y=e.getY();int action=e.getActionMasked();int w=getWidth(),h=getHeight();
        if(!started){started=true;return true;}
        if(gameOver||won){if(action==MotionEvent.ACTION_DOWN){restart();}return true;}
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
            if(x<220&&y>h-210){joyX=x;joyY=y;setMove(x,y,h);}
            else if(x>w-190&&y>h-190){firing=true;float dx=px-(camX+x),dy=py-(camY+y);float d=Math.max(1,(float)Math.hypot(dx,dy));aimX=dx/d;aimY=dy/d;}
            else if(x>w-290&&y>h-125){if(reserve>0){int n=Math.min(12-ammo,reserve);ammo+=n;reserve-=n;}}
            else if(x>w-160&&y>h-300&&medkits>0){hp=Math.min(100,hp+35);medkits--;}
            else {float dx=px-(camX+x),dy=py-(camY+y);float d=Math.max(1,(float)Math.hypot(dx,dy));aimX=dx/d;aimY=dy/d;}
        } else if(action==MotionEvent.ACTION_MOVE){if(joyX<220&&joyY>h-210)setMove(x,y,h);if(x>w-190&&y>h-220){float dx=px-(camX+x),dy=py-(camY+y);float d=Math.max(1,(float)Math.hypot(dx,dy));aimX=dx/d;aimY=dy/d;}}
        else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP){moveX=moveY=0;firing=false;}
        return true;
    }
    private void setMove(float x,float y,int h){float dx=x-100,dy=y-(h-105);float d=Math.max(1,(float)Math.hypot(dx,dy));moveX=dx/d;moveY=dy/d;}
    private void restart(){hp=100;ammo=12;reserve=48;kills=0;medkits=2;gameOver=won=false;enemies.clear();bullets.clear();px=worldW/2;py=worldH/2;for(int i=0;i<8;i++)spawnEnemy();}
}
